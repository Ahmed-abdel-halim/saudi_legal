<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\Auth\RegisterCompanyController;
use App\Http\Controllers\RequestController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\HowItWorksController;
use App\Http\Controllers\SupplierController;
use App\Http\Controllers\Auth\ActivationController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ExpertDashboardController;
use App\Http\Controllers\ChatController;
use App\Http\Controllers\LegalController;
use App\Http\Controllers\Auth\SuperAdminLoginController;

Route::get('/debug-articles', function () {
    return \App\Models\LegalArticle::take(5)->get();
});

// Home Route
Route::get('/', [HomeController::class, 'index'])->name('home');

// SAUDI LEGAL AI Assistant Public Routes (Temporary)
Route::get('/legal-assistant', [\App\Http\Controllers\LegalAiController::class, 'index'])->name('legal_assistant.public');
Route::post('/legal-assistant/ask', [\App\Http\Controllers\LegalAiController::class, 'ask'])->name('legal_assistant.public.ask');

// Careers Route
Route::get('/careers', [App\Http\Controllers\CareerController::class, 'index'])->name('careers');

// Blog Route
Route::get('/blog', [App\Http\Controllers\BlogController::class, 'index'])->name('blog');

// Authentication Routes
Route::get('/register/company', [RegisterCompanyController::class, 'showRegistrationForm'])->name('register.company');
Route::post('/register/company', [RegisterCompanyController::class, 'handleRegistration'])->name('register.company.handle');
Route::get('/register/student', [App\Http\Controllers\Auth\RegisterStudentController::class, 'showRegistrationForm'])->name('register.student');
Route::post('/register/student', [App\Http\Controllers\Auth\RegisterStudentController::class, 'handleRegistration'])->name('register.student.handle');


Route::get('/about', function () {
    return view('about');
})->name('about');

// Contact Us Route
Route::get('/contact', function () {
    return view('contact');
})->name('contact');
Route::post('/contact', function () {
    return back()->with('success', __('contact.CONTACT_SUCCESS_MESSAGE'));
})->name('contact.send');

// Login routes
Route::get('/login', function () {
    return view('auth.login');
})->name('login');
Route::post('/login', [App\Http\Controllers\Auth\LoginController::class, 'store'])->name('login.handle');

// OTP Verification Routes
Route::get('/verify-otp', [App\Http\Controllers\Auth\OtpVerificationController::class, 'show'])->name('verify-otp');
Route::post('/verify-otp/submit', [App\Http\Controllers\Auth\OtpVerificationController::class, 'verify'])->name('verify-otp.submit');
Route::post('/verify-otp/resend', [App\Http\Controllers\Auth\OtpVerificationController::class, 'resend'])->name('verify-otp.resend');

// Password reset routes
Route::get('/forgot-password', [\App\Http\Controllers\Auth\ForgotPasswordController::class, 'showLinkRequestForm'])->name('password.request');
Route::post('/forgot-password', [\App\Http\Controllers\Auth\ForgotPasswordController::class, 'sendResetLinkEmail'])->name('password.email');
Route::get('/reset-password/{token}', [\App\Http\Controllers\Auth\ResetPasswordController::class, 'showResetForm'])->name('password.reset');
Route::post('/reset-password', [\App\Http\Controllers\Auth\ResetPasswordController::class, 'reset'])->name('password.update');
Route::post('/logout', function () {
    // Revoke all Sanctum tokens for this user if authenticated via Sanctum
    if (auth()->check()) {
        auth()->user()->tokens()->delete();
    }
    \Illuminate\Support\Facades\Auth::logout();
    request()->session()->invalidate();
    request()->session()->regenerateToken();
    return redirect()->route('home')
        ->withCookie(cookie()->forget('superadmin_token'))
        ->withCookie(cookie()->forget('impersonation_token'))
        ->with('success', __('header.LOGOUT_SUCCESS', [], app()->getLocale()));
})->name('logout');

// Super Admin dedicated logout (redirect to SA login page)
Route::post('/superadmin/logout', function () {
    if (auth()->check()) {
        auth()->user()->tokens()->where('name', 'superadmin_token')->delete();
    }
    return redirect()->route('superadmin.login')
        ->withCookie(cookie()->forget('superadmin_token'))
        ->withCookie(cookie()->forget('impersonation_token'))
        ->with('success', 'You have been securely logged out of the admin portal.');
})->name('superadmin.logout');


// Public Expert's Dashboard Routes
Route::get('/dashboard/expert', [ExpertDashboardController::class, 'index'])->name('dashboard.expert');


Route::middleware(['auth'])->group(function () {

    // E X P E R T   A R E A
    Route::middleware(['expert'])->prefix('dashboard/expert')->name('dashboard.expert')->group(
        function () {
            Route::get('/', [ExpertDashboardController::class, 'index']);

            Route::get('/availability', [ExpertDashboardController::class, 'availability'])->name('.availability');
            Route::post('/availability', [ExpertDashboardController::class, 'availability']);

            Route::get('/cv-builder', [ExpertDashboardController::class, 'cvBuilder'])->name('.cv-builder');
            Route::post('/cv-builder', [ExpertDashboardController::class, 'cvBuilder']);

            Route::get('/services', [ExpertDashboardController::class, 'services'])->name('.services');
            Route::post('/services', [ExpertDashboardController::class, 'services']);
            Route::put('/services/{id}', [ExpertDashboardController::class, 'updateService'])->name('.services.update');
            Route::delete('/services/{id}', [ExpertDashboardController::class, 'deleteService'])->name('.services.delete');

            Route::get('/workbench', [\App\Http\Controllers\Dashboard\Expert\WorkbenchController::class, 'index'])->name('.workbench');
            Route::post('/workbench/action', [\App\Http\Controllers\Dashboard\Expert\WorkbenchController::class, 'action'])->name('.workbench.action');
            Route::post('/workbench/sentiment', [\App\Http\Controllers\Dashboard\Expert\WorkbenchController::class, 'submitSentiment'])->name('.workbench.sentiment');

            // SAUDI LEGAL Routes
            Route::get('/legal-workbench', [\App\Http\Controllers\Dashboard\Expert\LegalTaskController::class, 'index'])->name('.legal_workbench');
            Route::get('/legal-workbench/search-systems', [\App\Http\Controllers\Dashboard\Expert\LegalTaskController::class, 'searchSystems'])->name('.legal_workbench.search_systems');
            Route::get('/legal-workbench/search-articles', [\App\Http\Controllers\Dashboard\Expert\LegalTaskController::class, 'searchArticles'])->name('.legal_workbench.search_articles');
            Route::get('/legal-history', [\App\Http\Controllers\Dashboard\Expert\LegalTaskController::class, 'history'])->name('.legal_history');
            Route::post('/legal-workbench/submit', [\App\Http\Controllers\Dashboard\Expert\LegalTaskController::class, 'submit'])->name('.legal_workbench.submit');
            Route::post('/legal-workbench/skip', [\App\Http\Controllers\Dashboard\Expert\LegalTaskController::class, 'skip'])->name('.legal_workbench.skip');
            Route::post('/legal-workbench/previous', [\App\Http\Controllers\Dashboard\Expert\LegalTaskController::class, 'previous'])->name('.legal_workbench.previous');
            Route::post('/legal-workbench/delete-citation', [\App\Http\Controllers\Dashboard\Expert\LegalTaskController::class, 'deleteCitation'])->name('.legal_workbench.delete_citation');

            Route::get('/settings', [ExpertDashboardController::class, 'settings'])->name('.settings');
            Route::post('/purchase/{id}/accept', [ExpertDashboardController::class, 'acceptPurchase'])->name('.purchase.accept');
            Route::post('/settings', [ExpertDashboardController::class, 'settings']);

            // EXPERT CHAT routes (Prefix: dashboard.expert)
            Route::get('/messages', [ChatController::class, 'index'])->name('.chat.index');
            Route::get('/messages/{id}', [ChatController::class, 'show'])->name('.chat.show');
            Route::post('/messages/{id}/send', [ChatController::class, 'sendMessage'])->name('.chat.send');
            Route::delete('/messages/{id}', [ChatController::class, 'destroy'])->name('.chat.destroy');
        }
    );


    // C O M P A N Y   &   C L I E N T   A R E A
    Route::middleware(['company'])->group(
        function () {

            // Company's Dashboard Routes
            Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
            Route::get('/dashboard/tasks', [DashboardController::class, 'tasks'])->name('dashboard.tasks');
            Route::post('/dashboard/tasks/upload', [DashboardController::class, 'uploadTasks'])->name('dashboard.tasks.upload');
            Route::get('/dashboard/settings', [DashboardController::class, 'settings'])->name('dashboard.settings');
            Route::post('/dashboard/settings', [DashboardController::class, 'updateSettings'])->name('dashboard.settings.update');
            Route::get('/dashboard/projects', [DashboardController::class, 'projects'])->name('dashboard.projects');
            Route::get('/dashboard/projects/create', [App\Http\Controllers\ProjectController::class, 'create'])->name('dashboard.projects.create');
            Route::post('/dashboard/projects', [App\Http\Controllers\ProjectController::class, 'store'])->name('dashboard.projects.store');
            Route::get('/dashboard/team', [DashboardController::class, 'team'])->name('dashboard.team');
            Route::post('/dashboard/team/invite', [DashboardController::class, 'inviteMember'])->name('dashboard.team.invite');
            Route::put('/dashboard/team/{id}', [DashboardController::class, 'updateMember'])->name('dashboard.team.update');
            Route::delete('/dashboard/team/{id}', [DashboardController::class, 'deleteMember'])->name('dashboard.team.delete');

            // Client Governance Dashboard
            Route::get('/client/governance', [\App\Http\Controllers\Client\GovernanceDashboardController::class, 'index'])->name('client.governance.dashboard');
            Route::post('/client/governance/analyze', [\App\Http\Controllers\Client\GovernanceDashboardController::class, 'analyzeCsv'])->name('client.governance.analyze');
            Route::post('/client/governance/upload', [\App\Http\Controllers\Client\GovernanceDashboardController::class, 'uploadTasks'])->name('client.governance.upload');
            Route::get('/client/governance/tasks/delete-all', [\App\Http\Controllers\Client\GovernanceDashboardController::class, 'deleteAllTasks'])->name('client.governance.task.delete-all');
            Route::put('/client/governance/tasks/{id}', [\App\Http\Controllers\Client\GovernanceDashboardController::class, 'updateTask'])->name('client.governance.task.update');
            Route::delete('/client/governance/tasks/{id}', [\App\Http\Controllers\Client\GovernanceDashboardController::class, 'deleteTask'])->name('client.governance.task.delete');
            Route::post('/client/governance/tasks/{id}/duplicate', [\App\Http\Controllers\Client\GovernanceDashboardController::class, 'duplicateTask'])->name('client.governance.task.duplicate');

            Route::get('/client/dashboard/metrics', [\App\Http\Controllers\ClientDashboardController::class, 'getMetrics'])->name('client.dashboard.metrics');
            Route::get('/client/dashboard/metrics', [\App\Http\Controllers\ClientDashboardController::class, 'getMetrics'])->name('client.dashboard.metrics');

            // Service Purchase Completion route
            Route::post('/client/purchases/{id}/complete', [\App\Http\Controllers\ServiceController::class, 'completePurchase'])->name('client.purchases.complete');

            // COMPANY/CLIENT CHAT routes (Prefix: dashboard)
            Route::get('/dashboard/messages', [ChatController::class, 'index'])->name('dashboard.chat.index');
            Route::get('/dashboard/messages/{id}', [ChatController::class, 'show'])->name('dashboard.chat.show');
            Route::post('/dashboard/messages/{id}/send', [ChatController::class, 'sendMessage'])->name('dashboard.chat.send');
            Route::delete('/dashboard/messages/{id}', [ChatController::class, 'destroy'])->name('dashboard.chat.destroy');
        }
    );

    // Wallet Withdraw Routes
    Route::post('/wallet/withdraw', [\App\Http\Controllers\WalletController::class, 'withdraw'])->name('wallet.withdraw');
});

// Legal routes
Route::get('/legal/terms', [LegalController::class, 'terms'])->name('legal.terms');
Route::get('/legal/privacy', [LegalController::class, 'privacy'])->name('legal.privacy');
Route::get('/legal/msa', [LegalController::class, 'msa'])->name('legal.msa');
Route::get('/legal/nda', [LegalController::class, 'nda'])->name('legal.nda');

// Debug route to test notifications
Route::get('/test-notifications', function () {
    $user = auth()->user();

    if (!$user) {
        return response()->json(['error' => 'Not authenticated']);
    }

    return response()->json([
        'user_id' => $user->id,
        'user_name' => $user->name,
        'user_role' => $user->role ?? 'NULL',
        'pending_purchases' => \App\Models\ServicePurchase::where('expert_id', $user->id)
            ->where('status', 'pending')
            ->count(),
        'db_notifications' => $user->notifications()->count(),
        'unread_notifications' => $user->unreadNotifications()->count(),
    ]);
})->middleware('auth');

// Notifications (Web)
Route::prefix('notifications')->name('notifications.')->middleware('auth')->group(function () {
    Route::get('/', [App\Http\Controllers\Api\NotificationController::class, 'index'])->name('index');
    Route::get('/unread-count', [App\Http\Controllers\Api\NotificationController::class, 'unreadCount'])->name('unread-count');
    Route::post('/{id}/read', [App\Http\Controllers\Api\NotificationController::class, 'markAsRead'])->name('read');
    Route::post('/read-all', [App\Http\Controllers\Api\NotificationController::class, 'markAllAsRead'])->name('read-all');
});

// Chat Routes Moved to specific groups

// Requests Routes
Route::get('/requests/browse', [RequestController::class, 'browse'])->name('requests.browse');
Route::get('/requests/{id}', [RequestController::class, 'show'])->name('requests.show');
Route::post('/requests/{id}/offer', [App\Http\Controllers\RequestController::class, 'submitOffer'])->name('requests.offer.submit')->middleware('auth');
Route::get('/requests/{id}/proposal', [RequestController::class, 'proposal'])->name('requests.proposal');
// Proposal Route
Route::post('/requests/{id}/proposal', [App\Http\Controllers\RequestController::class, 'submitOffer'])->name('requests.proposal.submit')->middleware('auth');
Route::post('/requests/offer/{id}/accept', [App\Http\Controllers\RequestController::class, 'acceptOffer'])->name('requests.offer.accept')->middleware('auth');
Route::get('/requests/{id}/contact', [RequestController::class, 'contact'])->name('requests.contact');
Route::post('/requests/{id}/contact', function () {
    return back()->with('success', __('contact.CONTACT_SUCCESS_MESSAGE'));
})->name('requests.contact.send');

// Notifications (Web)
Route::prefix('notifications')->name('notifications.')->middleware('auth')->group(function () {
    Route::get('/', [App\Http\Controllers\Api\NotificationController::class, 'index'])->name('index');
    Route::get('/unread-count', [App\Http\Controllers\Api\NotificationController::class, 'unreadCount'])->name('unread-count');
    Route::post('/{id}/read', [App\Http\Controllers\Api\NotificationController::class, 'markAsRead'])->name('read');
    Route::post('/read-all', [App\Http\Controllers\Api\NotificationController::class, 'markAllAsRead'])->name('read-all');
});

// Services Routes
Route::get('/services/browse', [ServiceController::class, 'browse'])->name('services.browse');
Route::get('/services/rlhf', [App\Http\Controllers\PageController::class, 'rlhf'])->name('pages.services.rlhf');
Route::get('/services/hitl', [App\Http\Controllers\PageController::class, 'hitl'])->name('pages.services.hitl');
Route::get('/services/data-infrastructure', [App\Http\Controllers\PageController::class, 'dataInfrastructure'])->name('pages.services.data_infrastructure');
Route::get('/services/{id}', [ServiceController::class, 'show'])->name('services.show');
Route::get('/services/{id}/contact', [ServiceController::class, 'contact'])->name('services.contact');
Route::post('/services/{id}/contact', function () {
    return back()->with('success', __('contact.CONTACT_SUCCESS_MESSAGE')); // Reusing existing message key
})->name('services.contact.send');
Route::get('/services/{id}/request', [ServiceController::class, 'request'])->name('services.request');
Route::post('/services/{id}/request', [ServiceController::class, 'purchaseHours'])->name('services.request.send')->middleware('auth');

// How It Works Route
Route::get('/how-it-works', [HowItWorksController::class, 'index'])->name('how-it-works');
Route::get('/how-it-works/benefits', [HowItWorksController::class, 'benefits'])->name('how-it-works.benefits');
Route::get('/how-it-works/pricing', [HowItWorksController::class, 'pricing'])->name('how-it-works.pricing');
Route::get('/how-it-works/faq', [HowItWorksController::class, 'faq'])->name('how-it-works.faq');


Route::get('/activate/{id}', [ActivationController::class, 'show'])->name('activation.show')->middleware('signed');
Route::post('/activate/{id}', [ActivationController::class, 'activate'])->name('activation.handle');

// Suppliers Routes
Route::get('/suppliers/browse', [SupplierController::class, 'browse'])->name('suppliers.browse');
Route::get('/suppliers/{id}', [SupplierController::class, 'show'])->name('suppliers.show');

// ─── Super Admin Login Portal ─────────────────────────────────────────────
// GET: no throttle (just viewing the page)
Route::get('/superadmin', [SuperAdminLoginController::class, 'showLoginForm'])->name('superadmin.login');
// POST: rate-limited to 5 login attempts per 10 minutes per IP
Route::post('/superadmin', [SuperAdminLoginController::class, 'store'])->middleware('throttle:5,10')->name('superadmin.login.handle');

// Admin Routes
Route::middleware(['superadmin'])->prefix('admin')->name('admin.')->group(function () {
    // Super Admin Dashboard
    Route::get('/dashboard', [\App\Http\Controllers\Admin\AdminDashboardController::class, 'index'])->name('dashboard');

    // User Management
    Route::get('/legal-records', [\App\Http\Controllers\Admin\LegalManagementController::class, 'index'])->name('legal.index');
    Route::get('/legal-records/{id}', [\App\Http\Controllers\Admin\LegalManagementController::class, 'show'])->name('legal.show');

    // Azure Management
    Route::get('/azure', [\App\Http\Controllers\Admin\AzureManagementController::class, 'index'])->name('azure.index');
    Route::post('/azure/sync', [\App\Http\Controllers\Admin\AzureManagementController::class, 'sync'])->name('azure.sync');

    Route::get('/users', [\App\Http\Controllers\Admin\AdminUserController::class, 'index'])->name('users.index');
    Route::patch('/users/{id}/toggle-status', [\App\Http\Controllers\Admin\AdminUserController::class, 'toggleStatus'])->name('users.toggle-status');
    Route::delete('/users/{id}', [\App\Http\Controllers\Admin\AdminUserController::class, 'destroy'])->name('users.destroy');

    // Companies Management
    Route::get('/companies', [\App\Http\Controllers\Admin\AdminCompanyController::class, 'index'])->name('companies.index');
    Route::patch('/companies/{id}/toggle-verified', [\App\Http\Controllers\Admin\AdminCompanyController::class, 'toggleVerified'])->name('companies.toggle-verified');
    Route::delete('/companies/{id}', [\App\Http\Controllers\Admin\AdminCompanyController::class, 'destroy'])->name('companies.destroy');

    // Experts Management
    Route::get('/experts', [\App\Http\Controllers\Admin\AdminExpertController::class, 'index'])->name('experts.index');
    Route::get('/experts/{id}/tasks', [\App\Http\Controllers\Admin\AdminExpertController::class, 'tasks'])->name('experts.tasks');
    Route::patch('/experts/{id}/toggle-status', [\App\Http\Controllers\Admin\AdminExpertController::class, 'toggleStatus'])->name('experts.toggle-status');
    Route::delete('/experts/{id}', [\App\Http\Controllers\Admin\AdminExpertController::class, 'destroy'])->name('experts.destroy');

    // System Settings
    Route::get('/settings', [\App\Http\Controllers\Admin\AdminSettingsController::class, 'index'])->name('settings.index');
    Route::put('/settings', [\App\Http\Controllers\Admin\AdminSettingsController::class, 'update'])->name('settings.update');
    // Dispute Management
    Route::get('/disputes', [App\Http\Controllers\Admin\DisputeController::class, 'index'])->name('disputes.index');
    Route::get('/disputes/{type}/{id}', [App\Http\Controllers\Admin\DisputeController::class, 'show'])->name('disputes.show');
    Route::post('/disputes/{type}/{id}/resolve-company', [App\Http\Controllers\Admin\DisputeController::class, 'resolveForCompany'])->name('disputes.resolve-company');
    Route::post('/disputes/{type}/{id}/resolve-expert', [App\Http\Controllers\Admin\DisputeController::class, 'resolveForExpert'])->name('disputes.resolve-expert');
    Route::post('/disputes/{type}/{id}/message', [App\Http\Controllers\Admin\DisputeController::class, 'sendMessage'])->name('disputes.message');

    // Dataset Upload for Intelligent Routing System
    Route::get('/dataset/upload', [App\Http\Controllers\Dashboard\DatasetUploadController::class, 'index'])->name('dataset.upload');
    Route::post('/dataset/upload', [App\Http\Controllers\Dashboard\DatasetUploadController::class, 'upload'])->name('dataset.upload.store');

    // Sentiment Tasks
    Route::get('/sentiment/tasks', [App\Http\Controllers\Admin\SentimentTaskController::class, 'index'])->name('sentiment.index');
    Route::delete('/sentiment/tasks/delete-all', [App\Http\Controllers\Admin\SentimentTaskController::class, 'destroyAll'])->name('sentiment.delete-all');
    Route::delete('/sentiment/tasks/{id}', [App\Http\Controllers\Admin\SentimentTaskController::class, 'destroy'])->name('sentiment.destroy');

    // Services Board
    Route::get('/services', [\App\Http\Controllers\Admin\AdminServiceController::class, 'index'])->name('services.index');
    Route::patch('/services/{id}/toggle-status', [\App\Http\Controllers\Admin\AdminServiceController::class, 'toggleStatus'])->name('services.toggle-status');
    Route::delete('/services/{id}', [\App\Http\Controllers\Admin\AdminServiceController::class, 'destroy'])->name('services.destroy');

    // Financials
    Route::get('/financials', [\App\Http\Controllers\Admin\AdminFinancialController::class, 'index'])->name('financials.index');
    // Impersonation feature
    Route::post('/impersonate/{user}', [App\Http\Controllers\Admin\ImpersonationController::class, 'start'])->name('impersonate.start');
});

// Impersonation Stop Route (available to anyone with an impersonation_token cookie)
Route::post('/impersonate/stop', [App\Http\Controllers\Admin\ImpersonationController::class, 'stop'])
    ->name('impersonate.stop');


// Freelancer Routes
Route::get('/freelancer/register', [App\Http\Controllers\Auth\FreelancerRegisterController::class, 'showRegistrationForm'])->name('freelancer.register.form');
Route::post('/freelancer/register', [App\Http\Controllers\Auth\FreelancerRegisterController::class, 'register'])->name('freelancer.register');

Route::middleware(['auth', 'freelancer'])->prefix('freelancer')->name('freelancer.')->group(function () {
    Route::get('/onboarding/skills', [App\Http\Controllers\Freelancer\OnboardingController::class, 'showSkills'])->name('onboarding.skills');
    Route::post('/onboarding/skills', [App\Http\Controllers\Freelancer\OnboardingController::class, 'storeSkills'])->name('onboarding.skills.store');

    // Reuse Expert Dashboard
    Route::get('/dashboard', [ExpertDashboardController::class, 'index'])->name('dashboard');
});

// ─── Stripe Payment Routes ──────────────────────────────────────────────────
// Client-facing payment pages (auth required)
Route::middleware('auth')->prefix('payment')->name('payment.')->group(function () {
    Route::get('/checkout/{purchase}', [App\Http\Controllers\PaymentController::class, 'checkout'])->name('checkout');
    Route::get('/success', [App\Http\Controllers\PaymentController::class, 'success'])->name('success');
    Route::get('/cancel/{purchase}', [App\Http\Controllers\PaymentController::class, 'cancel'])->name('cancel');
});

// Stripe Webhook — NO auth, NO CSRF (signature verification is done inside the controller)
Route::post('/stripe/webhook', [App\Http\Controllers\PaymentController::class, 'webhook'])->name('stripe.webhook');

// Friendly GET handler so browsers don't see a raw 405 error
Route::get('/stripe/webhook', function () {
    return response()->json([
        'status' => 'ok',
        'message' => 'This endpoint accepts POST requests from Stripe only. Do not call it directly from a browser.',
        'docs' => 'https://stripe.com/docs/webhooks',
    ], 200);
});

// ─── B2B SaaS Public Pages (Crawlable for Google Approval) ───────────────────
Route::get('/api-docs', [App\Http\Controllers\PageController::class, 'apiDocs'])->name('pages.api_docs');
Route::get('/security-compliance', [App\Http\Controllers\PageController::class, 'securityCompliance'])->name('pages.security_compliance');

